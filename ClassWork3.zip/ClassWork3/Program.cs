﻿namespace ClassWork3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            
        }
    }
}